<?php
//$conn=mysql_connect ("localhost", "root",
//"") or die('Cannot connect to the database because: ' . mysql_error());
//mysql_select_db ("gpt");

$conn=mysql_connect ("localhost", "grinemc_blu", "blu14#") or die('Cannot connect to the database because: ' . mysql_error());
mysql_select_db ("grinemc_blu");

//$conn=mysql_connect("gruposecsa.db.7891571.hostedresource.com", "gruposecsa", "Mvarela69") OR DIE ('Unable to connect to database! Please try again later.');
//mysql_select_db("gruposecsa");
//mysql_query ("SET NAMES 'utf8'");
?>